import numpy as np
arr=np.arange(2,20)
element=arr[6]
print(element)
