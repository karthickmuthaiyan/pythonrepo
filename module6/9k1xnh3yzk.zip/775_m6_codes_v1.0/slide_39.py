import matplotlib.pyplot as plt, numpy

y = numpy.random.randn(1000)
plt.hist(y, 100)
plt.show()
