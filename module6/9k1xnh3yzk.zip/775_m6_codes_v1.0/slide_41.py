import matplotlib.pyplot as plt

plt.bar([1, 2, 3], [1, 4, 9])
plt.show()
