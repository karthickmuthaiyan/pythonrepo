import pandas as pd
import numpy as np

df = pd.Series(np.arange(1, 51))
print(df.values)